module.exports = {
  "development": {
    "username": "root",
    "password": null,
    "database": "tecnovision",
    "host": "127.0.0.1",
    "dialect": "mysql",
    "operatoAliases": false
  },
  "test": {
    "username": "root",
    "password": null,
    "database": "tecnovision",
    "host": "127.0.0.1",
    "dialect": "mysql",
    "operatoAliases": false
  },
  "production": {
    "username": "root",
    "password": null,
    "database": "tecnovision",
    "host": "127.0.0.1",
    "dialect": "mysql",
    "operatoAliases": false
  }
}
